---
name: An issue or feature request related to the GUI
about: Any report, issue or feature request related to the GUI should be reported at https://github.com/bitcoin-core/gui/issues/
title: Any report, issue or feature request related to the GUI should be reported at https://github.com/bitcoin-core/gui/issues/
labels: GUI
assignees: ''

---

Any report, issue or feature request related to the GUI should be reported at
https://github.com/bitcoin-core/gui/issues/
